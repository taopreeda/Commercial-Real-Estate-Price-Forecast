# Step 3: Forecast macro variables

AR(1) is used since this is a simplest method due to time constraints.


```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from itertools import product
from datetime import datetime
from statsmodels.tsa.arima_model import ARIMA
%matplotlib inline
```


```python
frm30yr = pd.read_csv('frm30yr.csv', index_col='period', parse_dates = True)
frm30yr_chg = pd.read_csv('frm30yr_chg.csv', index_col='period', parse_dates = True)
mkt_pop = pd.read_csv('mkt_pop.csv', index_col='period', parse_dates = True)
```


```python
cities_cbsa = ['12060', '14460', '16980', '19100', '26420', '31080', '33100', '35620', '37980', '47900']
```


```python
frm30yr.dropna(inplace=True)
frm30yr_chg.dropna(inplace=True)
mkt_pop.dropna(inplace=True)
```


```python
idx_pred = pd.DatetimeIndex(start=frm30yr.index.min(), end=datetime(2019,7,1), freq="QS", name='period')
frm30yr = frm30yr.reindex(idx_pred)
frm30yr_chg = frm30yr_chg.reindex(idx_pred)
mkt_pop = mkt_pop.reindex(idx_pred)
```

### AR(1) model function


```python
def ar_model(df,train_period_end):
    train, test = df[:train_period_end], df[train_period_end:]
    history = train.dropna()
    model = ARIMA(history, order=(1,0,0))
    model_fit = model.fit(disp=0)
    predictions = model_fit.predict(start=len(history), end=len(train)+len(test)-1, dynamic=False)
    return predictions
```

### One model for mortgage rate.


```python
frm30yr['mortgage30us'] = frm30yr['mortgage30us'].fillna(ar_model(frm30yr,'2017-10'))
```

### 10 models for population forecast for each CBSA.


```python
for i in cities_cbsa:
    mkt_pop[i] = mkt_pop[i].fillna(ar_model(mkt_pop[i],'2015-01'))
```

    /Users/preeda/anaconda/lib/python3.6/site-packages/statsmodels/base/model.py:473: HessianInversionWarning: Inverting hessian failed, no bse or cov_params available
      'available', HessianInversionWarning)



```python
frm30yr_chg = frm30yr.diff()
pop_gr = mkt_pop.pct_change()
```

### Save Dataset


```python
frm30yr.to_csv('frm30yr_pred.csv')
frm30yr_chg.to_csv('frm30yr_chg_pred.csv')
pop_gr.to_csv('pop_gr_pred.csv')
```

### Plot Charts


```python
frm30yr.plot()
```




    <matplotlib.axes._subplots.AxesSubplot at 0x11dc09d30>




    
![png](output_17_1.png)
    



```python
frm30yr_chg.plot()
```




    <matplotlib.axes._subplots.AxesSubplot at 0x11dc2ac18>




    
![png](output_18_1.png)
    


The rate is slightly increasing after 2017.


```python
nrow = 5
ncol = 2
fig, axes = plt.subplots(nrow, ncol)
fig.set_size_inches(20, 12)
# plot counter
count=0
i=0
for r in range(nrow):
    for c in range(ncol):
        pop_gr[cities_cbsa[i]].plot(ax=axes[r,c], title=cities_cbsa[i], legend=True)
        count+=1
        i+=1
fig.tight_layout()
```


    
![png](output_20_0.png)
    


Population growth rate is pretty stable.
