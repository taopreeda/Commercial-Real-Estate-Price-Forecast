# Step 2: Model Calibration and Testing

This model uses VAR (Vector Auto Regressive) method to estimate CPR (CPI return). It also uses GEE (Generalized Estimating Equation) to take into account correlation since each time T has 10 prices and they're correlated.


```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime
%matplotlib inline
```


```python
cities_cbsa = [12060, 14460, 16980, 19100, 26420, 31080, 33100, 35620, 37980, 47900]
```


```python
cpi = pd.read_csv('cpi_final.csv', index_col='period', parse_dates = True)
cpr = pd.read_csv('cpr_final.csv', index_col='period', parse_dates = True)
mean_all = pd.read_csv('mean_all.csv')
dist_all = pd.read_csv('dist_all.csv')
```


```python
cpr.describe().transpose()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>count</th>
      <th>mean</th>
      <th>std</th>
      <th>min</th>
      <th>25%</th>
      <th>50%</th>
      <th>75%</th>
      <th>max</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>cbsa</th>
      <td>480.0</td>
      <td>27470.000000</td>
      <td>11088.217298</td>
      <td>12060.000000</td>
      <td>16980.000000</td>
      <td>28750.000000</td>
      <td>35620.000000</td>
      <td>47900.000000</td>
    </tr>
    <tr>
      <th>ret</th>
      <td>480.0</td>
      <td>-0.018687</td>
      <td>0.202388</td>
      <td>-0.703909</td>
      <td>-0.101883</td>
      <td>0.004099</td>
      <td>0.111199</td>
      <td>0.475699</td>
    </tr>
    <tr>
      <th>mortgage30us</th>
      <td>480.0</td>
      <td>-0.093392</td>
      <td>0.270243</td>
      <td>-0.467211</td>
      <td>-0.302198</td>
      <td>-0.173126</td>
      <td>0.199300</td>
      <td>0.434324</td>
    </tr>
    <tr>
      <th>mortgage30us_l1</th>
      <td>480.0</td>
      <td>-0.084313</td>
      <td>0.269579</td>
      <td>-0.467211</td>
      <td>-0.297892</td>
      <td>-0.157963</td>
      <td>0.199300</td>
      <td>0.434324</td>
    </tr>
    <tr>
      <th>mortgage30us_l2</th>
      <td>480.0</td>
      <td>-0.073963</td>
      <td>0.272116</td>
      <td>-0.467211</td>
      <td>-0.297892</td>
      <td>-0.150475</td>
      <td>0.216990</td>
      <td>0.434324</td>
    </tr>
    <tr>
      <th>mortgage30us_chg</th>
      <td>480.0</td>
      <td>0.008708</td>
      <td>0.195707</td>
      <td>-0.516035</td>
      <td>-0.123511</td>
      <td>-0.030176</td>
      <td>0.133432</td>
      <td>0.483965</td>
    </tr>
    <tr>
      <th>mortgage30us_chg_l1</th>
      <td>480.0</td>
      <td>0.006098</td>
      <td>0.198051</td>
      <td>-0.516035</td>
      <td>-0.125625</td>
      <td>-0.030176</td>
      <td>0.133432</td>
      <td>0.483965</td>
    </tr>
    <tr>
      <th>mortgage30us_chg_l2</th>
      <td>480.0</td>
      <td>0.010238</td>
      <td>0.198954</td>
      <td>-0.516035</td>
      <td>-0.125625</td>
      <td>-0.014417</td>
      <td>0.142945</td>
      <td>0.483965</td>
    </tr>
    <tr>
      <th>return_l1</th>
      <td>480.0</td>
      <td>-0.015818</td>
      <td>0.204392</td>
      <td>-0.703909</td>
      <td>-0.101883</td>
      <td>0.008345</td>
      <td>0.113015</td>
      <td>0.475699</td>
    </tr>
    <tr>
      <th>return_l2</th>
      <td>480.0</td>
      <td>-0.014573</td>
      <td>0.204748</td>
      <td>-0.703909</td>
      <td>-0.101883</td>
      <td>0.011754</td>
      <td>0.116365</td>
      <td>0.475699</td>
    </tr>
    <tr>
      <th>fmhpr</th>
      <td>480.0</td>
      <td>-0.048571</td>
      <td>0.196049</td>
      <td>-0.577166</td>
      <td>-0.173539</td>
      <td>-0.047906</td>
      <td>0.071510</td>
      <td>0.496618</td>
    </tr>
    <tr>
      <th>fmhpr_l1</th>
      <td>480.0</td>
      <td>-0.046248</td>
      <td>0.202293</td>
      <td>-0.585001</td>
      <td>-0.183946</td>
      <td>-0.026688</td>
      <td>0.098662</td>
      <td>0.391584</td>
    </tr>
    <tr>
      <th>fmhpr_l2</th>
      <td>480.0</td>
      <td>-0.044193</td>
      <td>0.195304</td>
      <td>-0.628931</td>
      <td>-0.168111</td>
      <td>-0.042762</td>
      <td>0.076656</td>
      <td>0.509450</td>
    </tr>
    <tr>
      <th>hi_gr</th>
      <td>480.0</td>
      <td>-0.071842</td>
      <td>0.226222</td>
      <td>-0.628398</td>
      <td>-0.236671</td>
      <td>-0.049314</td>
      <td>0.084942</td>
      <td>0.579983</td>
    </tr>
    <tr>
      <th>hi_gr_l1</th>
      <td>480.0</td>
      <td>-0.072171</td>
      <td>0.223957</td>
      <td>-0.620309</td>
      <td>-0.229264</td>
      <td>-0.049571</td>
      <td>0.086760</td>
      <td>0.526463</td>
    </tr>
    <tr>
      <th>hi_gr_l2</th>
      <td>480.0</td>
      <td>-0.072231</td>
      <td>0.226296</td>
      <td>-0.638758</td>
      <td>-0.241208</td>
      <td>-0.045033</td>
      <td>0.081703</td>
      <td>0.561531</td>
    </tr>
    <tr>
      <th>pop_gr</th>
      <td>480.0</td>
      <td>-0.025527</td>
      <td>0.225459</td>
      <td>-0.560511</td>
      <td>-0.155509</td>
      <td>-0.017818</td>
      <td>0.073519</td>
      <td>0.803660</td>
    </tr>
    <tr>
      <th>pop_gr_l1</th>
      <td>480.0</td>
      <td>-0.008310</td>
      <td>0.241158</td>
      <td>-0.560511</td>
      <td>-0.148335</td>
      <td>-0.013102</td>
      <td>0.081756</td>
      <td>0.811545</td>
    </tr>
    <tr>
      <th>pop_gr_l2</th>
      <td>480.0</td>
      <td>0.009073</td>
      <td>0.255137</td>
      <td>-0.560511</td>
      <td>-0.142120</td>
      <td>-0.009678</td>
      <td>0.097848</td>
      <td>0.819558</td>
    </tr>
  </tbody>
</table>
</div>




```python
cpr['intercept'] = 1

cpr.reset_index(inplace=True)
```

## Variable Selection Process

This is a state-of-the-art. It has been going through multiple iterations. Note that I've implemented GEE after writing all the following programs and some variables are no longer significant. Unfortunately I don't have enough time to modify it. This is a room for improvements.

## Final Variables


```python
selected_vars = ['intercept','mortgage30us_l1','mortgage30us_chg_l1',
               'return_l1', 'pop_gr_l1']

y = cpr['ret']
X = cpr[selected_vars]
```


```python
import statsmodels.api as sm
import statsmodels.formula.api as smf
```

    /Users/preeda/anaconda/lib/python3.6/site-packages/statsmodels/compat/pandas.py:56: FutureWarning: The pandas.core.datetools module is deprecated and will be removed in a future version. Please use the pandas.tseries module instead.
      from pandas.core import datetools



```python
ex = sm.cov_struct.Exchangeable()
model1 = sm.GEE.from_formula("ret ~ mortgage30us_l1 + mortgage30us_chg_l1 + return_l1 + pop_gr_l1",
                             groups="period", data=cpr, cov_struct=ex)
result = model1.fit()
print(result.summary())
```

                                   GEE Regression Results                              
    ===================================================================================
    Dep. Variable:                         ret   No. Observations:                  480
    Model:                                 GEE   No. clusters:                       48
    Method:                        Generalized   Min. cluster size:                  10
                          Estimating Equations   Max. cluster size:                  10
    Family:                           Gaussian   Mean cluster size:                10.0
    Dependence structure:         Exchangeable   Num. iterations:                    13
    Date:                     Fri, 15 Nov 2019   Scale:                           0.014
    Covariance type:                    robust   Time:                         21:17:29
    =======================================================================================
                              coef    std err          z      P>|z|      [0.025      0.975]
    ---------------------------------------------------------------------------------------
    Intercept              -0.0212      0.015     -1.402      0.161      -0.051       0.008
    mortgage30us_l1        -0.1306      0.050     -2.624      0.009      -0.228      -0.033
    mortgage30us_chg_l1     0.1582      0.083      1.901      0.057      -0.005       0.321
    return_l1               0.5766      0.045     12.679      0.000       0.487       0.666
    pop_gr_l1               0.0422      0.031      1.348      0.178      -0.019       0.104
    ==============================================================================
    Skew:                          0.0117   Kurtosis:                       0.9862
    Centered skew:                 0.0411   Centered kurtosis:              1.0734
    ==============================================================================


Variable Selection Criteria:
- Intuitive Sign: Lower mortgage rate leads to higher price. Increasing rate means we're in a benign period. Return lag 1 shows a momentum. Population Growth lag 1 means the increase in population growth leads to a higher prices.
- P-value should be lower than 0.05 but 0.10 can be acceptable.

pop_gr_l1 = Population growth lag 1 and mortgage30us_chg_l1 = Morgage rate change lag 1 are not significant at 0.05 but we'll move forward with this.


```python
print(ex.summary())
```

    The correlation between two observations in the same cluster is 0.439


Correlation of two prices in the same period is 43.9%


```python
cpr['normreturn_pred'] = result.predict(X)
```


```python
cpi.reset_index(inplace=True)

cpi = cpi.merge(cpr, how='left', left_on=['period','cbsa'], right_on=['period','cbsa'])
cpi = cpi.merge(mean_all, how='left', left_on=['cbsa'], right_on=['cbsa'])
cpi = cpi.merge(dist_all, how='left', left_on=['cbsa'], right_on=['cbsa'])

mean_col = [col for col in cpi if col.startswith('mean')]
dist_col = [col for col in cpi if col.startswith('dist')]
```


```python
cpr_normpred = cpi.pivot(index='period', columns='cbsa', values='normreturn_pred')
mean_cpr = cpi.pivot(index='period', columns='cbsa', values='mean_cpr')
dist_cpr = cpi.pivot(index='period', columns='cbsa', values='dist_cpr')
cpi_actual = cpi.pivot(index='period', columns='cbsa', values='cpi')
```


```python
cpr_pred = (cpr_normpred * dist_cpr) + mean_cpr
cpi_pred = cpi_actual.shift(1) * (1 + cpr_pred)
```


```python
def w_to_l(df,id1,col1,col2):
    df.reset_index(inplace=True)
    df = pd.melt(df, id_vars=[id1],value_vars=df.columns[1:])
    df.columns = [id1,col1,col2]
    df[col1] = pd.to_numeric(df[col1])
    return df
```


```python
cpr_pred_long = w_to_l(cpr_pred,'period','cbsa','return_pred')
cpi_pred_long = w_to_l(cpi_pred,'period','cbsa','cpi_pred')
```

## Combine


```python
cpi.reset_index(inplace=True)
cpr_pred
cpi = cpi.merge(cpr_pred_long, how='left', left_on=['period','cbsa'], right_on=['period','cbsa'])
cpi = cpi.merge(cpi_pred_long, how='left', left_on=['period','cbsa'], right_on=['period','cbsa'])
```

# Performance Metrics


```python
print("Correlation = ", cpi[['return_pred','ret']].corr().iloc[0][1])
```

    Correlation =  0.811684493956


## Correlation by Zip


```python
print(cpi.groupby('cbsa')[['return_pred','ret']].corr().iloc[0::2,-1])
```

    cbsa              
    12060  return_pred    0.822272
    14460  return_pred    0.836695
    16980  return_pred    0.840452
    19100  return_pred    0.808352
    26420  return_pred    0.795886
    31080  return_pred    0.894359
    33100  return_pred    0.799784
    35620  return_pred    0.861514
    37980  return_pred    0.862149
    47900  return_pred    0.815946
    Name: ret, dtype: float64


## Correlation by Year
This is a room for improvements as well. More variables should be investigated. Note that the calculation is from a small sample size (4 qtrs * 10 areas = 40 data points).


```python
cpi.set_index(['period'], inplace=True)
cpi['year'] = cpi.index.year
```


```python
print(cpi.groupby('year')[['return_pred','ret']].corr().iloc[0::2,-1])
```

    year             
    2001  return_pred         NaN
    2002  return_pred         NaN
    2003  return_pred         NaN
    2004  return_pred         NaN
    2005  return_pred    0.157237
    2006  return_pred   -0.081824
    2007  return_pred   -0.184663
    2008  return_pred    0.463324
    2009  return_pred    0.135497
    2010  return_pred    0.568767
    2011  return_pred    0.595686
    2012  return_pred    0.269459
    2013  return_pred    0.608493
    2014  return_pred    0.264470
    2015  return_pred    0.224623
    2016  return_pred    0.528914
    2017  return_pred    0.600195
    Name: ret, dtype: float64


# Back-testing Chart


```python
cpi.reset_index(inplace=True)
cpi_short = cpi[['period','cbsa','cpi','cpi_pred']]
cpi_short.set_index(['period'], inplace=True)
cpi_short = cpi_short[str(cpr.period.min()):]
```


```python
cpi_short.reset_index(inplace=True)
```


```python
df = pd.DataFrame()
df = cpi_short.pivot(index='period', columns='cbsa', values='cpi')
df_est = cpi_short.pivot(index='period', columns='cbsa', values='cpi_pred')
```


```python
nrow=5
ncol=2
# make a list of all dataframes 
df_list = [df[cities_cbsa[0]] ,df[cities_cbsa[1]], df[cities_cbsa[2]], df[cities_cbsa[3]],df[cities_cbsa[4]],
           df[cities_cbsa[5]] ,df[cities_cbsa[6]], df[cities_cbsa[7]], df[cities_cbsa[8]],df[cities_cbsa[9]]]
df_est_list = [df_est[cities_cbsa[0]] ,df_est[cities_cbsa[1]], df_est[cities_cbsa[2]], df_est[cities_cbsa[3]], df_est[cities_cbsa[4]],
           df_est[cities_cbsa[5]] ,df_est[cities_cbsa[6]], df_est[cities_cbsa[7]], df_est[cities_cbsa[8]], df_est[cities_cbsa[9]]]

fig, axes = plt.subplots(nrow, ncol)
fig.set_size_inches(20, 12)

# plot counter
count=0
i=0
for r in range(nrow):
    for c in range(ncol):
        df_list[count].plot(ax=axes[r,c], title=cities_cbsa[i], label='actual', legend=True)
        df_est_list[count].plot(ax=axes[r,c], label='pred', legend=True)
        count+=1
        i+=1
fig.tight_layout()
```


    
![png](output_36_0.png)
    


# Save model results


```python
result.save("cadre_model.pickle")
```


```python
cpi.to_csv('cadre_cpi.csv', index=None)
```
